package com.example.dogactivitytracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.dogactivitytracker.Adapter.DogAdapter;
import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.Entity.Exercise;
import com.example.dogactivitytracker.ViewModel.DogViewModel;

import java.util.Date;
import java.util.List;

public class DietOrExerciseActivity extends AppCompatActivity {

    public static final int DIET = 5;
    public static final int EXERCISE = 6;

    private DogViewModel dietViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diet_or_exercise);

        setTitle("Diet or Exercise");


        Button buttonDiet = findViewById(R.id.DietButton);
        buttonDiet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentDiet = new Intent(DietOrExerciseActivity.this, AddDiet.class);
                startActivityForResult(intentDiet, DIET);
            }
        });

        Button buttonExercise = findViewById(R.id.ExerciseButton);
        buttonExercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentExercise = new Intent(DietOrExerciseActivity.this, AddExercise.class);
                startActivityForResult(intentExercise, EXERCISE);
            }
        });


        final DogAdapter adapter = new DogAdapter();
        // recyclerView1.setAdapter(adapter);

        dietViewModel = ViewModelProviders.of(this).get(DogViewModel.class);
        dietViewModel.getAllDiets().observe(this, new Observer<List<Diet>>() {
            @Override
            public void onChanged(List<Diet> diets) {
                adapter.setDiet(diets);
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == DIET && resultCode == RESULT_OK) {
            double calories = data.getDoubleExtra(AddDiet.EXTRA_CALORIES, 0.0);
            double servings = data.getDoubleExtra(AddDiet.EXTRA_SERVINGS, 0.0);
            Date date = (Date)data.getSerializableExtra(AddDiet.EXTRA_DATE);

            Diet diet = new Diet(calories, servings, date);

            dietViewModel.insertDiet(diet);

            Toast.makeText(this, "Diet saved", Toast.LENGTH_LONG).show();

        }

        else if (requestCode == EXERCISE && resultCode == RESULT_OK){
            double time = data.getDoubleExtra(AddExercise.EXTRA_TIME, 0.0);
            double miles = data.getDoubleExtra(AddExercise.EXTRA_MILES, 0.0);
            Date date = (Date)data.getSerializableExtra(AddDiet.EXTRA_DATE);

            Exercise exercise = new Exercise(miles, time, date);

            dietViewModel.insertExercise(exercise);

            Toast.makeText(this, "Exercise saved", Toast.LENGTH_LONG).show();
        }
    }
}
