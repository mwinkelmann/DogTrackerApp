package com.example.dogactivitytracker.DAO;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.dogactivitytracker.Entity.Diet;

import java.util.List;

@Dao
public interface DietDAO {

    @Insert
    void insertDiet(Diet diet);

    @Update
    void updateDiet(Diet diet);

    @Delete
    void deleteDiet(Diet diet);

    @Query("DELETE FROM DIET_TABLE ")
    void deleteAllDiets();

    @Query("SELECT * FROM diet_table ORDER BY date DESC")
    LiveData<List<Diet>> getAllDiets();


}
