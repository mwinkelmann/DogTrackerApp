package com.example.dogactivitytracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class AddEditDogActivity extends AppCompatActivity {

    public static final String EXTRA_ID =
            "com.example.dogactivitytracker.EXTRA_ID";
    public static final String EXTRA_NAME =
            "com.example.dogactivitytracker.EXTRA_NAME";
    public static final String EXTRA_GENDER =
            "com.example.dogactivitytracker.EXTRA_GENDER";
    public static final String EXTRA_BREED =
            "com.example.dogactivitytracker.EXTRA_BREED";
    public static final String EXTRA_AGE =
            "com.example.dogactivitytracker.EXTRA_AGE";
    public static final String EXTRA_WEIGHT =
            "com.example.dogactivitytracker.EXTRA_WEIGHT";



    private EditText editTextName;
    private EditText editTextGender;
    private EditText editTextBreed;
    private EditText editTextAge;
    private EditText editTextWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_dog);

        editTextName = findViewById(R.id.edit_text_dog_name);
        editTextGender = findViewById(R.id.edit_text_dog_gender);
        editTextBreed = findViewById(R.id.edit_text_dog_breed);
        editTextAge = findViewById(R.id.edit_text_dog_age);
        editTextWeight = findViewById(R.id.edit_text_dog_weight);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_black_24dp);

        Intent intent = getIntent();

        if(intent.hasExtra(EXTRA_ID)){
            setTitle("Edit Dog");
            editTextName.setText(intent.getStringExtra(EXTRA_NAME));
            editTextGender.setText(intent.getStringExtra(EXTRA_GENDER));
            editTextBreed.setText(intent.getStringExtra(EXTRA_BREED));
            editTextAge.setText(intent.getStringExtra(EXTRA_AGE));
            editTextWeight.setText(intent.getStringExtra(EXTRA_WEIGHT));
        } else{
            setTitle("Add Dog");
        }
    }

    private void saveDog(){
        String name = editTextName.getText().toString();
        String gender = editTextGender.getText().toString();
        String breed = editTextBreed.getText().toString();
        double age = Double.parseDouble(editTextAge.getText().toString());
        double weight = Double.parseDouble((editTextWeight.getText().toString()));

        if(name.trim().isEmpty() || gender.trim().isEmpty() || breed.trim().isEmpty()){
            Toast.makeText(this, "input doggy info", Toast.LENGTH_LONG).show();
            return;
        }
        Intent data = new Intent();
        data.putExtra(EXTRA_NAME, name);
        data.putExtra(EXTRA_GENDER, gender);
        data.putExtra(EXTRA_BREED, breed);
        data.putExtra(EXTRA_AGE, age);
        data.putExtra(EXTRA_WEIGHT, weight);

        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if(id != -1){
            data.putExtra(EXTRA_ID, id);
        }

        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_dog_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.save_dog:
                saveDog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
