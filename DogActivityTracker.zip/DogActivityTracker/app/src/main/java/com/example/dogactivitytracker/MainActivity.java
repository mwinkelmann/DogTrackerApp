package com.example.dogactivitytracker;

import android.content.Intent;
import android.os.Bundle;

import com.example.dogactivitytracker.Adapter.DogAdapter;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.ViewModel.DogViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final int ADD_DOG_REQUEST = 1;
    public static final int EDIT_DOG_REQUEST = 2;
    public static final int DIET_EXERCISE_DOG_REQUEST = 3;

    private DogViewModel dogViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setTitle("Dog Tracker");

        FloatingActionButton buttonAddDog = findViewById(R.id.button_add_dog);
        buttonAddDog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddEditDogActivity.class);
                startActivityForResult(intent, ADD_DOG_REQUEST);
            }
        });

        Button buttonDietExercise = findViewById(R.id.DietExerciseMode);
        buttonDietExercise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, DietExerciseDogList.class);
                startActivityForResult(intent, DIET_EXERCISE_DOG_REQUEST);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setHasFixedSize(true);

        final DogAdapter adapter = new DogAdapter();
        recyclerView.setAdapter(adapter);

        dogViewModel = ViewModelProviders.of(this).get(DogViewModel.class);
        dogViewModel.getAllDogs().observe(this, new Observer<List<Dog>>() {
            @Override
            public void onChanged(List<Dog> dogs) {
                adapter.setDogs(dogs);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT| ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                dogViewModel.delete(adapter.getDogAt(viewHolder.getAdapterPosition()));
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new DogAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Dog dog) {
                Intent intent = new Intent(MainActivity.this, AddEditDogActivity.class);
                intent.putExtra(AddEditDogActivity.EXTRA_ID, dog.getId());
                intent.putExtra(AddEditDogActivity.EXTRA_NAME, dog.getName());
                intent.putExtra(AddEditDogActivity.EXTRA_GENDER, dog.getGender());
                intent.putExtra(AddEditDogActivity.EXTRA_BREED, dog.getBreed());
                intent.putExtra(AddEditDogActivity.EXTRA_AGE, dog.getAge());
                intent.putExtra(AddEditDogActivity.EXTRA_WEIGHT, dog.getWeight());
                startActivityForResult(intent, EDIT_DOG_REQUEST);
            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == ADD_DOG_REQUEST && resultCode == RESULT_OK){
            String name = data.getStringExtra(AddEditDogActivity.EXTRA_NAME);
            String gender = data.getStringExtra(AddEditDogActivity.EXTRA_GENDER);
            String breed = data.getStringExtra(AddEditDogActivity.EXTRA_BREED);
            double age = data.getDoubleExtra(AddEditDogActivity.EXTRA_AGE, 0.0);
            double weight = data.getDoubleExtra(AddEditDogActivity.EXTRA_WEIGHT, 0.0);

            Dog dog = new Dog(name, gender, age, weight, breed);

            dogViewModel.insert(dog);

            Toast.makeText(this, "Dog saved", Toast.LENGTH_LONG).show();

        }
        else if(requestCode == EDIT_DOG_REQUEST && resultCode == RESULT_OK){
            int id = data.getIntExtra(AddEditDogActivity.EXTRA_ID, -1);

            if(id == -1){
                Toast.makeText(this, "Dog can not be updated", Toast.LENGTH_LONG).show();
                return;
            }

            String name = data.getStringExtra(AddEditDogActivity.EXTRA_NAME);
            String gender = data.getStringExtra(AddEditDogActivity.EXTRA_GENDER);
            String breed = data.getStringExtra(AddEditDogActivity.EXTRA_BREED);
            double age = data.getDoubleExtra(AddEditDogActivity.EXTRA_AGE, 0.0);
            double weight = data.getDoubleExtra(AddEditDogActivity.EXTRA_WEIGHT, 0.0);

            Dog dog = new Dog(name, gender, age, weight, breed);
            dog.setId(id);
            dogViewModel.update(dog);

            Toast.makeText(this, "Dog updated", Toast.LENGTH_LONG).show();
        }
        else if(requestCode == DIET_EXERCISE_DOG_REQUEST && resultCode == RESULT_OK){
            Toast.makeText(this, "Diet and Exercise Mode", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.Delete_all_dogs) {
            dogViewModel.deleteAllDogs();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
