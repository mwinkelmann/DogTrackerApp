package com.example.dogactivitytracker.Entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "diet_table")
public class Diet {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private double calorites_per_serving;
    private double number_servings;
    private Date date;

    @ForeignKey(entity = Dog.class, parentColumns = "id", childColumns = "dogID")
    private int dogID;

    public Diet(double calorites_per_serving, double number_servings, Date date) {
        this.calorites_per_serving = calorites_per_serving;
        this.number_servings = number_servings;
        this.date = date;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public double getCalorites_per_serving() {
        return calorites_per_serving;
    }

    public double getNumber_servings() {
        return number_servings;
    }

    public Date getDate() {
        return date;
    }

    public void setDogID(int dogID){ this.dogID = dogID; }
}
