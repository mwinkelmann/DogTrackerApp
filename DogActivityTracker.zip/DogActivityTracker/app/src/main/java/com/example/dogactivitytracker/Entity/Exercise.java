package com.example.dogactivitytracker.Entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "Exercise_table")
public class Exercise {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private double miles;
    private double time;
    private Date date;

    @ForeignKey(entity = Dog.class, parentColumns = "id", childColumns = "dogID")
    private int dogID;

    public Exercise(double miles, double time, Date date) {
        this.miles = miles;
        this.time = time;
        this.date = date;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public double getMiles() {
        return miles;
    }

    public double getTime() {
        return time;
    }

    public Date getDate() {
        return date;
    }

    public void setDogID(int dogID){ this.dogID = dogID; }
}
