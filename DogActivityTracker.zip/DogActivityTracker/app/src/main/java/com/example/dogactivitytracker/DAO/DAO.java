package com.example.dogactivitytracker.DAO;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.Entity.Exercise;

import java.util.List;

@Dao
public interface DAO {

    @Query("SELECT * FROM dog_table WHERE name = :name")
    Dog getDog(int name);

    @Query("SELECT * FROM dog_table")
    List<Dog> getDogs();

    @Query("SELECT * FROM diet_table WHERE dogID = :dogID")
    List<Diet> getDiets(int dogID);

    @Query("SELECT * FROM exercise_table WHERE dogID = :dogID")
    List<Exercise> getExercises(int dogID);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void saveDog(Dog dog);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void saveDogs(List<Dog> dogs);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void saveDiets(List<Diet> diets);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void saveExercises(List<Exercise> exercises);

}
