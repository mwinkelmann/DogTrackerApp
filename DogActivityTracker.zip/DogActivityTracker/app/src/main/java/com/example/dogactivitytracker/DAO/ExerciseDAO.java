package com.example.dogactivitytracker.DAO;


import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.dogactivitytracker.Entity.Exercise;

import java.util.List;

@Dao
public interface ExerciseDAO {

    @Insert
    void insertExercise(Exercise exercise);

    @Update
    void updateExercise(Exercise exercise);

    @Delete
    void deleteExercise(Exercise exercise);

    @Query("DELETE FROM EXERCISE_TABLE")
    void deleteAllExercises();

    @Query("SELECT * FROM exercise_table ORDER BY date DESC")
    LiveData<List<Exercise>> getAllExercises();
}
