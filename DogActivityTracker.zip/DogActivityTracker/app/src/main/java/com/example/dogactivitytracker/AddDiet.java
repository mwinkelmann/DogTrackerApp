package com.example.dogactivitytracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dogactivitytracker.Adapter.DogAdapter;
import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.ViewModel.DogViewModel;

import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class AddDiet extends AppCompatActivity {

    public static final String EXTRA_ID_DIET =
            "com.example.dogactivitytracker.EXTRA_ID_DIET";
    public static final String EXTRA_CALORIES =
            "com.example.dogactivitytracker.EXTRA_CALORIES";
    public static final String EXTRA_SERVINGS =
            "com.example.dogactivitytracker.EXTRA_SERVINGS";
    public static final String EXTRA_DATE =
            "com.example.dogactivitytracker.EXTRA_DATE";

    private EditText editTextCalories;
    private EditText editTextServings;
    private DatePicker datePicker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diet_item);

        editTextCalories = findViewById(R.id.number_picker_calories);
        editTextServings = findViewById(R.id.number_picker_servings);
        datePicker = findViewById(R.id.text_view_date);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_black_24dp);

        setTitle("Add Diet");

    }

    private void saveDiet(){
        double calroies = Double.parseDouble(editTextCalories.getText().toString());
        double servings = Double.parseDouble(editTextServings.getText().toString());
        Date date = getDateFromDatePicker(datePicker);

        Intent data = new Intent();
        data.putExtra(EXTRA_CALORIES, calroies);
        data.putExtra(EXTRA_SERVINGS, servings);
        data.putExtra(EXTRA_DATE, date);

        int id = getIntent().getIntExtra(EXTRA_ID_DIET, -1);
        if(id != -1){
            data.putExtra(EXTRA_ID_DIET, id);
        }

        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_dog_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.save_dog:
                saveDiet();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


    public static Date getDateFromDatePicker(DatePicker datePicker){
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year =  datePicker.getYear();

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        return calendar.getTime();
    }
}
