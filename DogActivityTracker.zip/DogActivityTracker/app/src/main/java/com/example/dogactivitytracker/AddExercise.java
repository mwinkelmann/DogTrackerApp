package com.example.dogactivitytracker;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Date;


public class AddExercise extends AppCompatActivity {

    public static final String EXTRA_ID_EXERCISE =
            "com.example.dogactivitytracker.EXTRA_ID_EXERCISE";
    public static final String EXTRA_MILES =
            "com.example.dogactivitytracker.EXTRA_MILES";
    public static final String EXTRA_TIME =
            "com.example.dogactivitytracker.EXTRA_TIME";
    public static final String EXTRA_DATE =
            "com.example.dogactivitytracker.EXTRA_DATE";

    private EditText editTextMiles;
    private EditText editTextTime;
    private DatePicker datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercise_item);

        editTextMiles = findViewById(R.id.number_picker_miles);
        editTextTime = findViewById(R.id.number_picker_time);
        datePicker = findViewById(R.id.text_view_date1);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_black_24dp);

        setTitle("Add Exercise");
    }

    private void saveExercise(){
        double miles = Double.parseDouble(editTextMiles.getText().toString());
        double time = Double.parseDouble(editTextTime.getText().toString());
        Date date = getDateFromDatePicker(datePicker);

        Intent data = new Intent();
        data.putExtra(EXTRA_MILES, miles);
        data.putExtra(EXTRA_TIME, time);
        data.putExtra(EXTRA_DATE, date);

        int id = getIntent().getIntExtra(EXTRA_ID_EXERCISE, -1);
        if(id != -1){
            data.putExtra(EXTRA_ID_EXERCISE, id);
        }

        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_dog_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.save_dog:
                saveExercise();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


    public static Date getDateFromDatePicker(DatePicker datePicker){
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year =  datePicker.getYear();

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        return calendar.getTime();
    }
}
