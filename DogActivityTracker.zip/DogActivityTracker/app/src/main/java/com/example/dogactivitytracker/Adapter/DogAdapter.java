package com.example.dogactivitytracker.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.Entity.Exercise;
import com.example.dogactivitytracker.R;

import java.util.ArrayList;
import java.util.List;

public class DogAdapter extends RecyclerView.Adapter<DogAdapter.DogHolder> {

    private List<Dog> dogs = new ArrayList<>();

    private List<Diet> diets = new ArrayList<>();

    private List<Exercise> exercises = new ArrayList<>();

    private OnItemClickListener listener;

    @NonNull
    @Override
    public DogHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemVIew = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dog_item, parent, false);
        return new DogHolder(itemVIew);
    }


    @Override
    public void onBindViewHolder(@NonNull DogHolder holder, int position) {
        Dog currentDog = dogs.get(position);
        holder.textViewDogName.setText(currentDog.getName());
        holder.textViewDogGender.setText(currentDog.getGender());
        holder.textViewDogBreed.setText(currentDog.getBreed());
        holder.textViewDogAge.setText(String.valueOf(currentDog.getAge()));
        holder.textViewDogWeight.setText(String.valueOf(currentDog.getWeight()));
    }

    @Override
    public int getItemCount() {
        System.out.println("SIZE OF DOGS :: " + dogs.size());
        System.out.println("SIZE OF DIET :: " + diets.size());
        System.out.println("SIZE OF EXERCISE :: " + exercises.size());
        return dogs.size();

    }

    public void setDogs(List<Dog> dogs){
        this.dogs = dogs;
        notifyDataSetChanged();
    }

    public void setDiet(List<Diet> diets){
        this.diets = diets;
        notifyDataSetChanged();
    }

    public void setExercises(List<Exercise> exercises){
        this.exercises = exercises;
        notifyDataSetChanged();
    }

    public Dog getDogAt(int position){
        return dogs.get(position);
    }

    class DogHolder extends RecyclerView.ViewHolder{
        private TextView textViewDogName;
        private TextView textViewDogGender;
        private TextView textViewDogBreed;
        private TextView textViewDogAge;
        private TextView textViewDogWeight;

        public DogHolder(View itemView) {
            super(itemView);
            textViewDogName = itemView.findViewById(R.id.text_view_dog_name);
            textViewDogGender = itemView.findViewById(R.id.text_view_dog_gender);
            textViewDogBreed = itemView.findViewById(R.id.text_view_dog_breed);
            textViewDogAge = itemView.findViewById(R.id.text_view_dog_age);
            textViewDogWeight = itemView.findViewById(R.id.text_view_dog_weight);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if(listener != null && position != RecyclerView.NO_POSITION){
                        listener.onItemClick(dogs.get(position));
                    }
                }
            });
        }
    }

    public interface  OnItemClickListener{
        void onItemClick(Dog dog);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.listener = listener;

    }
}
