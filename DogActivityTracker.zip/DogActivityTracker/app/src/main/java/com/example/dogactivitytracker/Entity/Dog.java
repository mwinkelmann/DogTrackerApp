package com.example.dogactivitytracker.Entity;


import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.List;

@Entity(tableName = "dog_table")
public class Dog {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    private String gender;
    private double age;
    private double weight;
    private String breed;

    @Ignore
    private List<Diet> diets;
    private List<Exercise> exercises;

    //Constructor for a new dog
    public Dog(String name, String gender, double age, double weight, String breed) {
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.weight = weight;
        this.breed = breed;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public double getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public String getBreed() {
        return breed;
    }

    public List<Diet> getDiets(){ return diets;}

    public List<Exercise> getExercises(){ return exercises;}

    public void setDiets(List<Diet> diets){
        this.diets = diets;
    }

    public void setExercises(List<Exercise> exercises){
        this.exercises = exercises;
    }
}
