package com.example.dogactivitytracker.Database;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.dogactivitytracker.DAO.DietDAO;
import com.example.dogactivitytracker.DAO.DogDAO;
import com.example.dogactivitytracker.DAO.ExerciseDAO;
import com.example.dogactivitytracker.DataTypeConverter;
import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.Entity.Exercise;

import java.util.Date;


@Database(entities = {Dog.class, Diet.class, Exercise.class}, version = 4, exportSchema = false)
@TypeConverters({DataTypeConverter.class})
public abstract class DogDatabase extends RoomDatabase {

    private static DogDatabase instance;

    public abstract DogDAO dogDAO();

    public abstract DietDAO dietDAO();

    public abstract ExerciseDAO exerciseDAO();

    public static synchronized DogDatabase getInstance(Context context){
        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    DogDatabase.class, "dog_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback).build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new PopulateDbAsyncTask(instance).execute();
        }
    };

    private static class PopulateDbAsyncTask extends AsyncTask<Void, Void, Void>{
        private DogDAO dogDAO;
        private DietDAO dietDAO;
        private ExerciseDAO exerciseDAO;


        private PopulateDbAsyncTask(DogDatabase db){
            dogDAO = db.dogDAO();
            dietDAO = db.dietDAO();
            exerciseDAO = db.exerciseDAO();

        }

        @Override
        protected Void doInBackground(Void... voids){

            dogDAO.insert(new Dog("Kehona", "Female",
                    2.4, 42.5, "Shepherd Mix"));
            dietDAO.insertDiet(new Diet(435.5, 1.5,
                    new Date(2019, 20, 11)));
            exerciseDAO.insertExercise(new Exercise(2.5, 44.3,
                    new Date(2019, 20, 11)));

            return null;
        }
    }
}
