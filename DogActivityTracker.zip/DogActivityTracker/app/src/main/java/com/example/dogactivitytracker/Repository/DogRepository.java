package com.example.dogactivitytracker.Repository;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.dogactivitytracker.DAO.DietDAO;
import com.example.dogactivitytracker.DAO.DogDAO;
import com.example.dogactivitytracker.DAO.ExerciseDAO;
import com.example.dogactivitytracker.Database.DogDatabase;
import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.Entity.Exercise;

import java.util.List;

public class DogRepository {

    private DogDAO dogDAO;

    private LiveData<List<Dog>> allDogs;


    public DogRepository(Application application){
        DogDatabase database = DogDatabase.getInstance(application);
        dogDAO = database.dogDAO();
        allDogs = dogDAO.getAllDogs();
        dietDAO = database.dietDAO();
        allDiets = dietDAO.getAllDiets();
        exerciseDAO = database.exerciseDAO();
        allExercises = exerciseDAO.getAllExercises();
    }

    public void insert(Dog dog){
        new InsertDogAsyncTask(dogDAO).execute(dog);
    }

    public void update(Dog dog){
        new UpdateDogAsyncTask(dogDAO).execute(dog);
    }

    public void delete(Dog dog){
        new DeleteDogAsyncTask(dogDAO).execute(dog);
    }

    public void deleteAllDogs(){
        new DeleteAllDogAsyncTask(dogDAO).execute();
    }

    public LiveData<List<Dog>> getAllDogs() {
        return allDogs;
    }

    private static class InsertDogAsyncTask extends AsyncTask<Dog, Void, Void>{
        private DogDAO dogDAO;

        private InsertDogAsyncTask(DogDAO dogDAO){
            this.dogDAO = dogDAO;
        }

        @Override
        protected Void doInBackground(Dog... dogs){
            dogDAO.insert(dogs[0]);
            return null;
        }
    }

    private static class UpdateDogAsyncTask extends AsyncTask<Dog, Void, Void>{
        private DogDAO dogDAO;

        private UpdateDogAsyncTask(DogDAO dogDAO){
            this.dogDAO = dogDAO;
        }

        @Override
        protected Void doInBackground(Dog... dogs){
            dogDAO.update(dogs[0]);
            return null;
        }
    }

    private static class DeleteDogAsyncTask extends AsyncTask<Dog, Void, Void>{
        private DogDAO dogDAO;

        private DeleteDogAsyncTask(DogDAO dogDAO){
            this.dogDAO = dogDAO;
        }

        @Override
        protected Void doInBackground(Dog... dogs){
            dogDAO.delete(dogs[0]);
            return null;
        }
    }

    private static class DeleteAllDogAsyncTask extends AsyncTask<Void, Void, Void>{
        private DogDAO dogDAO;

        private DeleteAllDogAsyncTask(DogDAO dogDAO){
            this.dogDAO = dogDAO;
        }

        @Override
        protected Void doInBackground(Void... voids){
            dogDAO.deleteAllDogs();
            return null;
        }
    }

    private DietDAO dietDAO;

    private LiveData<List<Diet>> allDiets;

    public void insertDiet(Diet diet) { new DogRepository.InsertDietAsyncTask(dietDAO).execute(diet); }

    public void updateDiet(Diet diet) { new DogRepository.UpdateDietAsyncTask(dietDAO).execute(diet); }

    public void deleteDiet(Diet diet) { new DogRepository.DeleteDietAsyncTask(dietDAO).execute(diet); }

    public void deleteAllDiets(){ new DogRepository.DeleteAllDietsAsyncTask(dietDAO).execute(); }

    public LiveData<List<Diet>> getAllDiets(){
        return allDiets;
    }


    private static class InsertDietAsyncTask extends AsyncTask<Diet, Void, Void> {
        private DietDAO dietDAO;

        private InsertDietAsyncTask(DietDAO dietDAO){
            this.dietDAO = dietDAO;
        }

        @Override
        protected Void doInBackground(Diet... diets){
            dietDAO.insertDiet(diets[0]);
            return null;
        }
    }

    private static class DeleteDietAsyncTask extends AsyncTask<Diet, Void, Void>{
        private DietDAO dietDAO;

        private DeleteDietAsyncTask(DietDAO dietDAO){
            this.dietDAO = dietDAO;
        }

        @Override
        protected Void doInBackground(Diet... diets){
            dietDAO.deleteDiet(diets[0]);
            return null;
        }
    }

    private static class UpdateDietAsyncTask extends AsyncTask<Diet, Void, Void>{
        private DietDAO dietDAO;

        private UpdateDietAsyncTask(DietDAO dietDAO){
            this.dietDAO = dietDAO;
        }

        @Override
        protected Void doInBackground(Diet... diets){
            dietDAO.updateDiet(diets[0]);
            return null;
        }
    }

    private static class DeleteAllDietsAsyncTask extends AsyncTask<Void, Void, Void>{
        private DietDAO dietDAO;

        private DeleteAllDietsAsyncTask(DietDAO dietDAO){
            this.dietDAO = dietDAO;
        }

        @Override
        protected Void doInBackground(Void... voids){
            dietDAO.deleteAllDiets();
            return null;
        }
    }

    private ExerciseDAO exerciseDAO;

    private LiveData<List<Exercise>> allExercises;

    public void insertExercise(Exercise exercise){new DogRepository.InsertExerciseAsyncTask(exerciseDAO).execute(exercise);}

    public void updateExercise(Exercise exercise){ new DogRepository.UpdateExerciseAsyncTask(exerciseDAO).execute(exercise);}

    public void deleteExercise(Exercise exercise){ new DeleteExerciseAsyncTask(exerciseDAO).execute(exercise);}

    public void deleteAllExercises(){new DogRepository.DeleteAllExercisesAsyncTask(exerciseDAO).execute();}

    public LiveData<List<Exercise>> getAllExercises(){return allExercises;}

    private static class InsertExerciseAsyncTask extends AsyncTask<Exercise, Void, Void> {
        private ExerciseDAO exerciseDAO;

        private InsertExerciseAsyncTask(ExerciseDAO exerciseDAO){
            this.exerciseDAO = exerciseDAO;
        }

        @Override
        protected Void doInBackground(Exercise... exercises){
            exerciseDAO.insertExercise(exercises[0]);
            return null;
        }
    }

    private static class UpdateExerciseAsyncTask extends AsyncTask<Exercise, Void, Void> {
        private ExerciseDAO exerciseDAO;

        private UpdateExerciseAsyncTask(ExerciseDAO exerciseDAO){
            this.exerciseDAO = exerciseDAO;
        }

        @Override
        protected Void doInBackground(Exercise... exercises){
            exerciseDAO.insertExercise(exercises[0]);
            return null;
        }
    }

    private static class DeleteExerciseAsyncTask extends AsyncTask<Exercise, Void, Void> {
        private ExerciseDAO exerciseDAO;

        private DeleteExerciseAsyncTask(ExerciseDAO exerciseDAO){
            this.exerciseDAO = exerciseDAO;
        }

        @Override
        protected Void doInBackground(Exercise... exercises){
            exerciseDAO.insertExercise(exercises[0]);
            return null;
        }
    }

    private static class DeleteAllExercisesAsyncTask extends AsyncTask<Void, Void, Void>{
        private ExerciseDAO exerciseDAO;

        private DeleteAllExercisesAsyncTask(ExerciseDAO exerciseDAO){
            this.exerciseDAO = exerciseDAO;
        }

        @Override
        protected Void doInBackground(Void... voids){
            exerciseDAO.deleteAllExercises();
            return null;
        }
    }
}
