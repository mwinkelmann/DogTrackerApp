package com.example.dogactivitytracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.dogactivitytracker.Adapter.DogAdapter;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.ViewModel.DogViewModel;

import java.util.List;

public class DietExerciseDogList extends AppCompatActivity {

    public static final int DIET_OR_EXERCISE = 4;

    private DogViewModel dogViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet_exercise_dog_list);

        setTitle("Choose a Dog");


        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setHasFixedSize(true);

        final DogAdapter adapter = new DogAdapter();
        recyclerView.setAdapter(adapter);

        dogViewModel = ViewModelProviders.of(this).get(DogViewModel.class);
        dogViewModel.getAllDogs().observe(this, new Observer<List<Dog>>() {
            @Override
            public void onChanged(List<Dog> dogs) {
                adapter.setDogs(dogs);
            }
        });


        adapter.setOnItemClickListener(new DogAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Dog dog) {
                Intent intent = new Intent(DietExerciseDogList.this, DietOrExerciseActivity.class);
                intent.putExtra(AddEditDogActivity.EXTRA_ID, dog.getId());
                intent.putExtra(AddEditDogActivity.EXTRA_NAME, dog.getName());
                intent.putExtra(AddEditDogActivity.EXTRA_GENDER, dog.getGender());
                intent.putExtra(AddEditDogActivity.EXTRA_BREED, dog.getBreed());
                intent.putExtra(AddEditDogActivity.EXTRA_AGE, dog.getAge());
                intent.putExtra(AddEditDogActivity.EXTRA_WEIGHT, dog.getWeight());
                startActivityForResult(intent, DIET_OR_EXERCISE);
            }
        });
    }
}
