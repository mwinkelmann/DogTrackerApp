package com.example.dogactivitytracker.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.dogactivitytracker.Entity.Diet;
import com.example.dogactivitytracker.Entity.Dog;
import com.example.dogactivitytracker.Entity.Exercise;
import com.example.dogactivitytracker.Repository.DogRepository;

import java.util.List;

public class DogViewModel extends AndroidViewModel {

    private DogRepository repository;

    private LiveData<List<Dog>> allDogs;
    private LiveData<List<Diet>> allDiets;
    private LiveData<List<Exercise>> allExercises;

    public DogViewModel(@NonNull Application application) {
        super(application);
        repository = new DogRepository(application);
        allDogs = repository.getAllDogs();
        allDiets = repository.getAllDiets();
        allExercises = repository.getAllExercises();
    }

    public void insert(Dog dog){
        repository.insert(dog);
    }

    public void update(Dog dog){
        repository.update(dog);
    }

    public void delete(Dog dog){
        repository.delete(dog);
    }

    public void deleteAllDogs(){
        repository.deleteAllDogs();
    }

    public LiveData<List<Dog>> getAllDogs(){
        return allDogs;
    }

    public void insertDiet(Diet diet){
        repository.insertDiet(diet);
    }

    public void updateDiet(Diet diet){
        repository.updateDiet(diet);
    }

    public void deleteDiet(Diet diet){
        repository.deleteDiet(diet);
    }

    public void deleteAllDiet(){
        repository.deleteAllDiets();
    }

    public LiveData<List<Diet>> getAllDiets(){ return allDiets; }

    public void insertExercise(Exercise exercise) { repository.insertExercise(exercise);}

    public void updateExercise(Exercise exercise) { repository.updateExercise(exercise);}

    public void deleteExercise(Exercise exercise) { repository.deleteExercise(exercise);}

    public void deleteAllExercise(Exercise exercise) { repository.deleteAllExercises();}

    public LiveData<List<Exercise>> getAllExercises() { return allExercises; }


}
